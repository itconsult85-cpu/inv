<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <title>Invoice In <?= esc($invoice['invoice_no']) ?></title>
    <style>
        @page {
            size: A4;
            margin: 15mm
        }

        body {
            font: 12px Arial;
            color: #111
        }

        .page {
            max-width: 180mm;
            margin: auto
        }

        .header {
            display: flex;
            justify-content: space-between;
            border-bottom: 2px solid #444;
            padding-bottom: 8px
        }

        .logo {
            width: 42mm
        }

        .title {
            text-align: center;
            background: #444;
            color: #fff;
            padding: 8px;
            font-size: 18px;
            margin: 14px 0
        }

        .info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px
        }

        .info table {
            width: 100%
        }

        .info th {
            text-align: left
        }

        .items {
            width: 100%;
            border-collapse: collapse;
            margin-top: 18px
        }

        .items th,
        .items td {
            border: 1px solid #555;
            padding: 6px
        }

        .items th {
            background: #ddd
        }

        .right {
            text-align: right
        }

        .cancel {
            border: 3px solid #c00;
            color: #c00;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            padding: 8px
        }

        @media print {
            button {
                display: none
            }
        }
    </style>
</head>

<body>
    <div class="page"><?php if ($invoice['status'] !== 'AKTIF'): ?><div class="cancel">DIBATALKAN</div><?php endif ?><div class="header"><img class="logo" src="<?= base_url('image/logo.png') ?>">
            <div style="text-align:right"><strong>PT TRISENTOSA RAYA ESOLUSI</strong><br>Dokumen Pencatatan Tagihan Supplier</div>
        </div>
        <div class="title">INVOICE IN</div>
        <div class="info">
            <table>
                <tr>
                    <th>No. Invoice</th>
                    <td><?= esc($invoice['invoice_no']) ?></td>
                </tr>
                <tr>
                    <th>Tanggal</th>
                    <td><?= date('d-m-Y', strtotime($invoice['invoice_date'])) ?></td>
                </tr>
                <tr>
                    <th>Supplier</th>
                    <td><?= esc($invoice['supplier_name']) ?></td>
                </tr>
            </table>
            <table>
                <tr>
                    <th>Jenis Sumber</th>
                    <td><?= ucfirst(esc($invoice['source_type'])) ?> Masuk</td>
                </tr>
                <tr>
                    <th>No. Transaksi</th>
                    <td><?= esc(explode('||', (string) $invoice['source_no'], 2)[0]) ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td><?= esc($invoice['status']) ?></td>
                </tr>
            </table>
        </div>
        <table class="items">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. Surat Jalan</th>
                    <th>Kode dan Nama Item</th>
                    <th>Qty</th>
                    <th>UoM</th>
                    <th>Harga</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody><?php foreach ($details as $i => $d): ?><tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= esc($d['no_surat_jalan'] ?: '-') ?></td>
                        <td><?= esc($d['item_code'] . ' - ' . $d['item_name']) ?></td>
                        <td class="right"><?= number_format($d['qty'], 0, ',', '.') ?></td>
                        <td><?= esc($d['unit']) ?></td>
                        <td class="right"><?= number_format($d['unit_price'], 0, ',', '.') ?></td>
                        <td class="right"><?= number_format($d['amount'], 0, ',', '.') ?></td>
                    </tr><?php endforeach ?><tr>
                    <td colspan="5" rowspan="<?= 2 + ((int) ($invoice['ppn_enabled'] ?? 1) === 1 ? 1 : 0) + ((int) ($invoice['pph_enabled'] ?? 1) === 1 ? 1 : 0) + ((int) ($invoice['dp_enabled'] ?? 0) === 1 ? 1 : 0) ?>" style="border:0"></td>
                    <th>Subtotal</th>
                    <td class="right"><?= number_format($invoice['subtotal'], 0, ',', '.') ?></td>
                </tr><?php if ((int) ($invoice['ppn_enabled'] ?? 1) === 1): ?><tr>
                        <th>PPN <?= number_format((float) ($invoice['ppn_percent'] ?? 11), 0, ',', '.') ?>%</th>
                        <td class="right"><?= number_format($invoice['ppn'], 0, ',', '.') ?></td>
                    </tr><?php endif ?><?php if ((int) ($invoice['pph_enabled'] ?? 1) === 1): ?><tr>
                        <th>PPh 23 (<?= number_format((float) ($invoice['pph_percent'] ?? 2), 0, ',', '.') ?>%)</th>
                        <td class="right"><?= number_format($invoice['pph23'], 0, ',', '.') ?></td>
                    </tr><?php endif ?><?php if ((int) ($invoice['dp_enabled'] ?? 0) === 1): ?><tr>
                        <th><?= ($invoice['dp_mode'] ?? 'percent') === 'amount' ? 'DP Nominal' : 'DP ' . number_format((float) ($invoice['dp_percent'] ?? 50), 0, ',', '.') . '%' ?></th>
                        <td class="right"><?= number_format((float) ($invoice['dp_amount'] ?? 0), 0, ',', '.') ?></td>
                    </tr><?php endif ?><tr>
                    <th>Grand Total</th>
                    <td class="right"><strong><?= number_format($invoice['grand_total'], 0, ',', '.') ?></strong></td>
                </tr>
            </tbody>
        </table>
    </div>
    <script>
        window.onload = () => window.print();
    </script>
</body>

</html>