<?= $this->extend('main/layout') ?>

<?= $this->section('judul') ?>
Form Edit Data Produk
<?= $this->endSection('judul') ?>

<?= $this->section('subjudul') ?>

<button type="button" class="btn btn-warning" onclick="location.href=('/barang/index')">
    <i class="fa fa-undo"></i> Kembali
</button>

<?= $this->endSection('subjudul') ?>

<?= $this->section('isi') ?>
<?= form_open('barang/updatedata', ['id' => 'formProduk']) ?>
<?php
$flashError = session()->getFlashdata('error');
$flashSukses = session()->getFlashdata('sukses');
if (is_array($flashError)) {
    $flashError = '<div class="alert alert-danger"><ul class="mb-0"><li>' . implode('</li><li>', array_map('esc', $flashError)) . '</li></ul></div>';
}
if (is_array($flashSukses)) {
    $flashSukses = '<div class="alert alert-success"><ul class="mb-0"><li>' . implode('</li><li>', array_map('esc', $flashSukses)) . '</li></ul></div>';
}
?>
<?= $flashError ?>
<?= $flashSukses ?>
<?php
$kodeDapatDiubah = (bool) ($kodeDapatDiubah ?? false);
$pemakaianKodeProduk = $pemakaianKodeProduk ?? [];
$labelPemakaianKode = implode(', ', array_map(static function ($row) {
    return ($row['label'] ?? '-') . ' (' . ($row['jumlah'] ?? 0) . ')';
}, $pemakaianKodeProduk));
?>

<div class="card mb-3">
    <div class="card-header py-2"><strong>Informasi Dasar</strong></div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="kodebarang">Kode Produk</label>
                    <input type="text" class="form-control" id="kodebarang" name="kodebarang" value="<?= esc($kodebarang) ?>" <?= $kodeDapatDiubah ? '' : 'readonly' ?>>
                    <?php if ($kodeDapatDiubah) : ?>
                        <small class="text-muted">Bisa diubah karena belum dipakai transaksi.</small>
                    <?php else : ?>
                        <small class="text-muted">Tidak bisa diubah, sudah dipakai di: <?= esc($labelPemakaianKode ?: 'transaksi lain') ?>.</small>
                    <?php endif ?>
                    <input type="hidden" class="form-control" id="old_kodebarang" name="old_kodebarang" value="<?= esc($kodebarang) ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="namabarang">Nama Produk</label>
                    <input type="text" class="form-control" id="namabarang" placeholder="Input Nama Produk" name="namabarang" value="<?= $namabarang ?>" autofocus>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="idpel">Pelanggan</label>
                    <select name="idpel" id="idpel" class="tre-combobox-source d-none">
                        <?php foreach ($datapelanggan as $pel) : ?>
                            <?php if ($pel['pelid'] == $idpel) : ?>
                                <option selected value="<?= $pel['pelid'] ?>"><?= $pel['pelnama'] ?></option>
                            <?php else : ?>
                                <option value="<?= $pel['pelid'] ?>"><?= $pel['pelnama'] ?></option>
                            <?php endif; ?>
                        <?php endforeach ?>
                    </select>
                    <div class="tre-combobox" data-target="idpel">
                        <input type="text" class="form-control tre-combobox-input" placeholder="-- Pilih Pelanggan --" autocomplete="off">
                        <div class="tre-combobox-menu"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="kategori">Kategori</label>
                    <select name="kategori" id="kategori" class="tre-combobox-source d-none">
                        <?php foreach ($datakategori as $kat) : ?>
                            <?php if ($kat['katid'] == $kategori) : ?>
                                <option selected value="<?= $kat['katid'] ?>"><?= $kat['katnama'] ?></option>
                            <?php else : ?>
                                <option value="<?= $kat['katid'] ?>"><?= $kat['katnama'] ?></option>
                            <?php endif; ?>
                        <?php endforeach ?>
                    </select>
                    <div class="tre-combobox" data-target="kategori">
                        <input type="text" class="form-control tre-combobox-input" placeholder="-- Pilih Kategori --" autocomplete="off">
                        <div class="tre-combobox-menu"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="satuan">Satuan Produk</label>
                    <select name="satuan" id="satuan" class="tre-combobox-source d-none">
                        <?php foreach ($datasatuan as $sat) : ?>
                            <?php if ($sat['satid'] == $satuan) : ?>
                                <option selected value="<?= $sat['satid'] ?>"><?= $sat['satnama'] ?></option>
                            <?php else : ?>
                                <option value="<?= $sat['satid'] ?>"><?= $sat['satnama'] ?></option>
                            <?php endif; ?>
                        <?php endforeach ?>
                    </select>
                    <div class="tre-combobox" data-target="satuan">
                        <input type="text" class="form-control tre-combobox-input" placeholder="-- Pilih Satuan --" autocomplete="off">
                        <div class="tre-combobox-menu"></div>
                    </div>
                    <input type="hidden" name="satuanberat" id="satuanberat" value="<?= $satuanberat ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group pt-md-4 mt-md-2">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="tanpaBerat" name="tanpa_berat" value="1" <?= !empty($tanpaBerat) ? 'checked' : '' ?>>
                        <label class="custom-control-label font-weight-bold" for="tanpaBerat">Produk jasa / tanpa berat</label>
                    </div>
                    <small class="form-text text-muted">Pakai untuk jasa jahit/konsinyasi yang belum punya data berat material atau berat produk jadi.</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="sumberMaterial">Sumber Material Produksi</label>
                    <select name="sumber_material" id="sumberMaterial" class="form-control">
                        <option value="tre" <?= ($sumberMaterial ?? 'tre') === 'tre' ? 'selected' : '' ?>>Material TRE</option>
                        <option value="vendor" <?= ($sumberMaterial ?? 'tre') === 'vendor' ? 'selected' : '' ?>>Material dari Customer</option>
                        <option value="beli_jadi" <?= ($sumberMaterial ?? 'tre') === 'beli_jadi' ? 'selected' : '' ?>>Beli Barang Jadi (Full dari Vendor)</option>
                    </select>
                    <small class="form-text text-muted">Pilih customer kalau material tidak masuk stok TRE dan hanya dicatat sebagai referensi produk. Pilih "Beli Barang Jadi" kalau produk ini nggak pernah diproduksi di TRE sama sekali -- selalu dibeli barang jadi dari vendor lewat PO Out, jadi nggak butuh material apapun.</small>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header py-2"><strong>Harga &amp; Stok</strong></div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="harga">Harga Produk</label>
                    <input type="number" class="form-control" id="harga" placeholder="Input Harga Produk" name="harga" value="<?= $harga ?>" autofocus>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="minstok">Minimal Stok Produk</label>
                    <input type="number" class="form-control" id="minstok" name="minstok" value="<?= $minstok ?>" autofocus>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header py-2"><strong>Material &amp; Berat</strong></div>
    <div class="card-body">
        <div class="form-group">
            <label for="material">Material</label>
            <select name="material[]" id="material" class="form-control select2" multiple="multiple" data-placeholder="-- Pilih satu atau lebih material --" style="width: 100%;">
                <?php foreach ($datamaterial as $mat) : ?>
                    <option value="<?= $mat['matid'] ?>" data-matsatid="<?= $mat['matsatid'] ?>" <?= in_array((int) $mat['matid'], $material, true) ? 'selected' : '' ?>>
                        <?= $mat['matnama'] ?>
                    </option>
                <?php endforeach ?>
            </select>
            <small class="form-text text-muted" id="materialHelp">Wajib untuk produk barang biasa. Untuk produk jasa/tanpa berat, material boleh hanya sebagai referensi atau dikosongkan.</small>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Berat Material Terpakai <small class="text-muted">(input dalam gram)</small></label>
                    <div id="materialBeratContainer" class="berat-material-container text-muted">
                        Pilih material terlebih dahulu.
                    </div>
                    <small class="form-text text-muted">Isi berat tiap material yang dibutuhkan untuk membuat 1 pcs produk ini (referensi, bisa beda dari berat produk jadi kalau ada susut/kepotong).</small>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="totalMaterialTerpakai">Total Material Terpakai <small class="text-muted">(referensi, Kg)</small></label>
                    <input type="number" step="0.0001" min="0" class="form-control" id="totalMaterialTerpakai" placeholder="0.0000" readonly>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="wise">Wise <small class="text-muted">(% material yang kebuang/susut pas produksi)</small></label>
                    <input type="number" step="0.01" min="0" max="100" class="form-control" id="wise" name="wise" placeholder="mis. 12.5" value="<?= $wise !== null ? esc($wise) : '' ?>">
                    <small class="form-text text-muted">Persentase dari Total Material Terpakai yang kebuang/susut jadi waste pas produksi. Dipakai buat nyaranin Berat 1 Pcs Produk Jadi di bawah, dan buat laporan Material Terbuang. Opsional, kosongin kalau tidak tahu.</small>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="beratProdukJadi">Berat 1 Pcs Produk Jadi <small class="text-muted">(input dalam gram)</small></label>
                    <input type="number" step="0.0001" min="0.0001" class="form-control" id="beratProdukJadi" name="berat_produk_jadi" placeholder="Berat produk jadi dalam gram" required>
                    <small class="form-text text-muted">Berat aktual produk setelah jadi. Otomatis disarankan dari Total Material Terpakai x (1 - Wise%), tapi boleh ditimpa manual kalau perlu. Ini yang dipakai buat hitung berat pengiriman.</small>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label class="mb-1">Hasil Kalkulasi</label>
            <div class="berat-material-container">
                <div class="row">
                    <div class="col-md-3"><strong>PCS/KG:</strong> <span id="hasilPcsPerKg">-</span></div>
                    <div class="col-md-3"><strong>Estimasi Waste/Pcs:</strong> <span id="hasilWastePcs">-</span></div>
                    <div class="col-md-3"><strong>Harga Material Terakhir/KG:</strong> <span id="hasilHargaMaterialKg">-</span></div>
                    <div class="col-md-3"><strong>Harga Material/PCS:</strong> <span id="hasilHargaMaterialPcs">-</span></div>
                </div>
                <small class="form-text text-muted">Dihitung otomatis dari Total Material Terpakai, Wise, dan harga pembelian material terakhir -- bukan angka tersimpan, selalu ter-update.</small>
            </div>
        </div>
    </div>
</div>

<div class="form-group">
    <button type="submit" class="btn btn-success">Simpan</button>
</div>
<?= form_close() ?>
<script>
    var materialBeratContainer = document.getElementById('materialBeratContainer');
    var totalBeratElement = document.getElementById('totalMaterialTerpakai');
    var beratProdukJadiElement = document.getElementById('beratProdukJadi');
    var tanpaBeratElement = document.getElementById('tanpaBerat');
    var sumberMaterialElement = document.getElementById('sumberMaterial');
    var beratMaterialAwal = <?= json_encode($beratMaterial, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    var GRAM_KE_KG = 1000;
    // Berat Produk Jadi sudah tersimpan sebelumnya (dari input manual lama)
    // -- jangan ditimpa otomatis pas halaman baru dibuka, biarin apa adanya
    // sampai user sendiri yang ubah Total Material Terpakai/Wise.
    var beratProdukJadiManual = <?= $beratProdukJadi !== null ? 'true' : 'false' ?>;

    <?php if ($beratProdukJadi !== null) : ?>
        beratProdukJadiElement.value = <?= json_encode((float) $beratProdukJadi * 1000) ?>;
    <?php endif ?>

    function hitungTotalBerat() {
        var totalGram = 0;
        materialBeratContainer.querySelectorAll('.berat-material').forEach(function(input) {
            totalGram += parseFloat(input.value) || 0;
        });
        totalBeratElement.value = (totalGram / GRAM_KE_KG).toFixed(4);
        hitungKalkulasiWise();
    }

    function tampilkanBeratMaterial() {
        if (tanpaBeratElement.checked || sumberMaterialElement.value === 'vendor' || sumberMaterialElement.value === 'beli_jadi') {
            var pesan = sumberMaterialElement.value === 'vendor'
                ? 'Material dari customer: detail berat material tidak wajib dan tidak dihitung sebagai kebutuhan material TRE.'
                : sumberMaterialElement.value === 'beli_jadi'
                ? 'Beli barang jadi dari vendor: material tidak dipakai, jadi tidak perlu diisi.'
                : 'Produk jasa/tanpa berat: detail berat material tidak wajib diisi.';
            materialBeratContainer.innerHTML = '<span class="text-muted">' + pesan + '</span>';
            totalBeratElement.value = '0.0000';
            return;
        }

        var selected = Array.from(document.getElementById('material').selectedOptions);
        materialBeratContainer.innerHTML = '';

        if (selected.length === 0) {
            materialBeratContainer.innerHTML = '<span class="text-muted">Pilih material terlebih dahulu.</span>';
            totalBeratElement.value = '';
            return;
        }

        selected.forEach(function(opt) {
            var wrapper = document.createElement('div');
            wrapper.className = 'form-group mb-2';

            var label = document.createElement('label');
            label.textContent = opt.textContent;

            var input = document.createElement('input');
            input.type = 'number';
            input.step = '0.0001';
            input.min = '0.0001';
            input.required = true;
            input.className = 'form-control berat-material';
            input.name = 'berat_material[' + opt.value + ']';
            input.placeholder = 'Berat dalam gram';
            if (beratMaterialAwal[opt.value] !== undefined) {
                // Tersimpan di database dalam Kg, ditampilkan dalam gram.
                input.value = (parseFloat(beratMaterialAwal[opt.value]) * GRAM_KE_KG).toString();
            }
            input.addEventListener('input', hitungTotalBerat);

            wrapper.appendChild(label);
            wrapper.appendChild(input);
            materialBeratContainer.appendChild(wrapper);
        });

        hitungTotalBerat();
    }

    function toggleTanpaBerat() {
        var isVendorMaterial = sumberMaterialElement.value === 'vendor';
        if (isVendorMaterial) {
            tanpaBeratElement.checked = true;
        }
        var isTanpaBerat = tanpaBeratElement.checked || isVendorMaterial;
        beratProdukJadiElement.required = !isTanpaBerat;
        beratProdukJadiElement.disabled = isTanpaBerat;
        if (isTanpaBerat) {
            beratProdukJadiElement.value = '0';
        } else if (<?= $beratProdukJadi !== null ? 'false' : 'true' ?>) {
            beratProdukJadiElement.value = '';
        }
        document.getElementById('materialHelp').textContent = isVendorMaterial
            ? 'Material tetap boleh dipilih sebagai referensi, tapi stok/kebutuhan material TRE tidak akan ikut dihitung.'
            : sumberMaterialElement.value === 'beli_jadi'
            ? 'Produk dibeli jadi dari vendor: material tidak perlu diisi sama sekali.'
            : isTanpaBerat
            ? 'Material boleh dipilih sebagai referensi, tapi tidak wajib dan tidak perlu berat.'
            : 'Wajib untuk produk barang biasa. Untuk produk jasa/tanpa berat, material boleh hanya sebagai referensi atau dikosongkan.';
        tampilkanBeratMaterial();
    }

    var wiseElement = document.getElementById('wise');
    var hasilPcsPerKgElement = document.getElementById('hasilPcsPerKg');
    var hasilWastePcsElement = document.getElementById('hasilWastePcs');
    var hasilHargaMaterialKgElement = document.getElementById('hasilHargaMaterialKg');
    var hasilHargaMaterialPcsElement = document.getElementById('hasilHargaMaterialPcs');
    var hargaMaterialTerakhirKg = null;

    function formatRupiahKalkulasi(value) {
        return 'Rp ' + new Intl.NumberFormat('id-ID').format(Math.round(value));
    }

    // Total Material Terpakai (kg, sudah termasuk bagian yang bakal kebuang)
    // + Wise% -> Berat Produk Jadi disaranin otomatis (boleh ditimpa manual),
    // dan sisanya (Total Material Terpakai x Wise%) itu estimasi waste-nya.
    function hitungKalkulasiWise() {
        var totalMaterialKg = parseFloat(totalBeratElement.value) || 0;
        var wisePersen = parseFloat(wiseElement.value) || 0;

        if (totalMaterialKg <= 0) {
            hasilPcsPerKgElement.textContent = '-';
            hasilWastePcsElement.textContent = '-';
            hasilHargaMaterialPcsElement.textContent = '-';
            return;
        }

        hasilPcsPerKgElement.textContent = (1 / totalMaterialKg).toLocaleString('id-ID', { maximumFractionDigits: 4 });

        var wasteKg = totalMaterialKg * (wisePersen / 100);
        var beratProdukJadiSaranKg = Math.max(totalMaterialKg - wasteKg, 0);
        hasilWastePcsElement.textContent = (wasteKg * GRAM_KE_KG).toLocaleString('id-ID', { maximumFractionDigits: 4 }) + ' gram';

        if (!beratProdukJadiManual && !beratProdukJadiElement.disabled) {
            beratProdukJadiElement.value = (beratProdukJadiSaranKg * GRAM_KE_KG).toFixed(4);
        }

        hasilHargaMaterialPcsElement.textContent = hargaMaterialTerakhirKg !== null
            ? formatRupiahKalkulasi(totalMaterialKg * hargaMaterialTerakhirKg)
            : '-';
    }

    function ambilHargaMaterialTerakhir() {
        var selectedOption = document.getElementById('material').selectedOptions[0];
        if (!selectedOption) {
            hargaMaterialTerakhirKg = null;
            hasilHargaMaterialKgElement.textContent = '-';
            hitungKalkulasiWise();
            return;
        }

        $.getJSON('/barang/hargaMaterialTerakhir', { matid: selectedOption.value }, function(response) {
            hargaMaterialTerakhirKg = response.harga !== null && response.harga !== undefined ? Number(response.harga) : null;
            hasilHargaMaterialKgElement.textContent = hargaMaterialTerakhirKg !== null
                ? formatRupiahKalkulasi(hargaMaterialTerakhirKg)
                : 'Belum ada histori pembelian';
            hitungKalkulasiWise();
        }).fail(function() {
            hargaMaterialTerakhirKg = null;
            hasilHargaMaterialKgElement.textContent = '-';
            hitungKalkulasiWise();
        });
    }

    $('#material').on('change', function() {
        var selectedOption = this.selectedOptions[0];
        if (selectedOption) {
            document.getElementById('satuanberat').value = selectedOption.getAttribute('data-matsatid');
        }
        tampilkanBeratMaterial();
        ambilHargaMaterialTerakhir();
    });

    beratProdukJadiElement.addEventListener('input', function() {
        // Field beneran dikosongin (bukan cuma lagi ketik angka baru) --
        // balikin ke mode saran otomatis lagi, jangan nyangkut manual
        // selamanya cuma gara-gara sempet dihapus.
        var kosong = beratProdukJadiElement.value.trim() === '';
        beratProdukJadiManual = !kosong;
        if (kosong) {
            hitungKalkulasiWise();
        }
    });
    wiseElement.addEventListener('input', hitungKalkulasiWise);

    tanpaBeratElement.addEventListener('change', toggleTanpaBerat);
    sumberMaterialElement.addEventListener('change', toggleTanpaBerat);

    $(document).ready(function() {
        toggleTanpaBerat();
        ambilHargaMaterialTerakhir();
    });

    // Input berat per material ditampilkan & diisi dalam gram (lebih mudah
    // buat angka kecil), tapi yang beneran dikirim ke server harus dalam Kg
    // (satuan yang dipakai tabel berat/berat_material) -- jadi dikonversi
    // pas submit, bukan pas diketik, biar tampilannya tetap gram terus.
    document.getElementById('formProduk').addEventListener('submit', function() {
        syncTreComboboxValues();
        if (tanpaBeratElement.checked) {
            beratProdukJadiElement.disabled = false;
            beratProdukJadiElement.value = '0';
            return;
        }

        materialBeratContainer.querySelectorAll('.berat-material').forEach(function(input) {
            var gram = parseFloat(input.value) || 0;
            input.value = (gram / GRAM_KE_KG).toFixed(6);
        });
        var gramProdukJadi = parseFloat(beratProdukJadiElement.value) || 0;
        beratProdukJadiElement.value = (gramProdukJadi / GRAM_KE_KG).toFixed(6);
    });

    // Keterangan panjang di bawah tiap field disembunyiin default biar form
    // nggak kelihatan penuh -- diganti link "Info" kecil yang bisa
    // di-klik buat buka-tutup. Otomatis, nggak perlu sentuh HTML tiap field.
    document.querySelectorAll('.form-text.text-muted').forEach(function(el) {
        var toggle = document.createElement('a');
        toggle.href = '#';
        toggle.className = 'form-text-toggle';
        toggle.setAttribute('aria-expanded', 'false');
        toggle.innerHTML = '<i class="fas fa-info-circle"></i> Info <i class="fas fa-chevron-down"></i>';
        el.classList.add('d-none');
        el.parentNode.insertBefore(toggle, el);
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            var tersembunyi = el.classList.toggle('d-none');
            toggle.setAttribute('aria-expanded', tersembunyi ? 'false' : 'true');
        });
    });
</script>

<style>
    .form-text-toggle {
        align-items: center;
        color: #6c757d;
        display: inline-flex;
        font-size: .8rem;
        gap: 4px;
        margin-top: .25rem;
        text-decoration: none;
    }

    .form-text-toggle:hover,
    .form-text-toggle:focus {
        color: #495057;
        text-decoration: none;
    }

    .form-text-toggle .fa-chevron-down {
        font-size: .65rem;
        transition: transform .15s ease;
    }

    .form-text-toggle[aria-expanded="true"] .fa-chevron-down {
        transform: rotate(180deg);
    }

    .tre-combobox {
        position: relative;
    }

    .tre-combobox-menu {
        background: #fff;
        border: 1px solid #80bdff;
        border-radius: 0 0 0.25rem 0.25rem;
        box-shadow: 0 0.35rem 0.75rem rgba(15, 23, 42, .12);
        display: none;
        left: 0;
        max-height: 15rem;
        overflow-y: auto;
        position: absolute;
        right: 0;
        top: calc(100% - 1px);
        z-index: 1050;
    }

    .tre-combobox.is-open .tre-combobox-input {
        border-color: #80bdff;
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .tre-combobox.is-open .tre-combobox-menu {
        display: block;
    }

    .tre-combobox-option {
        cursor: pointer;
        padding: .55rem .85rem;
    }

    .tre-combobox-option:hover,
    .tre-combobox-option.is-active {
        background: #0d6efd;
        color: #fff;
    }

    .tre-combobox-empty {
        color: #6c757d;
        padding: .55rem .85rem;
    }

    #material + .select2-container .select2-selection--multiple {
        height: calc(2.25rem + 2px) !important;
        min-height: calc(2.25rem + 2px) !important;
        padding: 0.375rem 0.75rem !important;
        background-color: #fff !important;
        border: 1px solid #ced4da !important;
        border-radius: 0.25rem !important;
        box-sizing: border-box;
        overflow: hidden;
    }

    #material + .select2-container .select2-selection__rendered {
        display: flex !important;
        align-items: center;
        height: 100%;
        padding: 0 !important;
        margin: 0 !important;
        overflow-x: auto;
    }

    #material + .select2-container .select2-search--inline {
        display: flex;
        align-items: center;
    }

    #material + .select2-container .select2-search__field {
        height: auto !important;
        margin: 0 !important;
        padding: 0 !important;
        border: 0 !important;
    }

    #material + .select2-container .select2-selection__choice {
        color: #000 !important;
        background-color: #f1f1f1 !important;
        border: 1px solid #ced4da !important;
        margin-top: 0 !important;
    }

    #material + .select2-container .select2-selection__choice__remove {
        color: #000 !important;
    }

    #material + .select2-container.select2-container--focus
    .select2-selection--multiple {
        border-color: #80bdff !important;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .berat-material-container {
        border: 1px dashed #ced4da;
        border-radius: 0.25rem;
        padding: 0.6rem 0.75rem;
        background-color: #f8f9fa;
    }

    .berat-material-container .form-group:last-child {
        margin-bottom: 0;
    }
</style>
<script>
    function initTreComboboxes() {
        $('.tre-combobox').each(function() {
            const $box = $(this);
            const $select = $('#' + $box.data('target'));
            const $input = $box.find('.tre-combobox-input');
            const $menu = $box.find('.tre-combobox-menu');

            function options() {
                return $select.find('option').map(function() {
                    return {
                        value: this.value,
                        text: $(this).text()
                    };
                }).get().filter(function(option) {
                    return option.value !== '';
                });
            }

            function render(query) {
                const normalized = (query || '').toLowerCase();
                const filtered = options().filter(function(option) {
                    return option.text.toLowerCase().includes(normalized);
                });

                $menu.empty();
                if (filtered.length === 0) {
                    $menu.append('<div class="tre-combobox-empty">Tidak ada data yang cocok.</div>');
                    return;
                }

                filtered.forEach(function(option, index) {
                    $('<div class="tre-combobox-option"></div>')
                        .toggleClass('is-active', index === 0)
                        .text(option.text)
                        .attr('data-value', option.value)
                        .appendTo($menu);
                });
            }

            function setSelected(value, text) {
                $select.val(value).trigger('change');
                $input.val(text);
                $box.removeClass('is-open');
            }

            const selectedText = $select.find('option:selected').val() ? $select.find('option:selected').text() : '';
            $input.val(selectedText);

            $input.on('focus input', function() {
                render(this.value);
                $box.addClass('is-open');
            });

            $input.on('keydown', function(event) {
                const $active = $menu.find('.tre-combobox-option.is-active');
                if (event.key === 'Enter' && $active.length) {
                    event.preventDefault();
                    setSelected($active.data('value'), $active.text());
                }
            });

            $menu.on('mousedown', '.tre-combobox-option', function(event) {
                event.preventDefault();
                setSelected($(this).data('value'), $(this).text());
            });

            $input.on('blur', function() {
                window.setTimeout(function() {
                    const typed = $input.val().trim().toLowerCase();
                    const match = options().find(function(option) {
                        return option.text.toLowerCase() === typed;
                    });
                    if (match) {
                        setSelected(match.value, match.text);
                    } else if (!typed) {
                        $select.val('');
                    }
                    $box.removeClass('is-open');
                }, 120);
            });
        });
    }

    function syncTreComboboxValues() {
        $('.tre-combobox').each(function() {
            const $box = $(this);
            const $select = $('#' + $box.data('target'));
            const typed = $box.find('.tre-combobox-input').val().trim().toLowerCase();
            let matchedValue = '';

            $select.find('option').each(function() {
                if (this.value !== '' && $(this).text().trim().toLowerCase() === typed) {
                    matchedValue = this.value;
                    return false;
                }
            });

            $select.val(matchedValue);
        });
    }

    $(document).ready(initTreComboboxes);
</script>
<?= $this->endSection('isi') ?>
